function displayMessage() {
	alert("Hello, World!");
}
