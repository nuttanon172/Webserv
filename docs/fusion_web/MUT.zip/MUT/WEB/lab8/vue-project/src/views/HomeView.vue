<script setup>
import Student from '../components/Student.vue'
import TheWelcome from '../components/TheWelcome.vue'
</script>

<template>
  <main>
    <Student name="Natthanon" lname="Tairattanapong"></Student>
    <TheWelcome />
  </main>
</template>
